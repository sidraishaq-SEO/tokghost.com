# TokGhost.com — SEO Master Tracker

Live SERP + competitor analysis + on-page meta for every page.
Built page by page. Each entry = ready to paste into the page head + WordPress later.

Year reference: 2026. Author/brand: TokGhost.

---

## PAGE 1 — HOMEPAGE / PROFILE VIEWER  [HTML: DONE]

### Target keywords
- Primary: anonymous tiktok viewer
- Secondary: tiktok profile viewer, view tiktok without account, tiktok viewer online, tiktok viewer anonymous

### Live SERP analysis (checked)
Who ranks: anonymous-viewer.com, ttviewer.net, tikvib.com, tikface.com, tikviewr.com, ssstik.io, trollishly.com, exporttok.com, spybroski.com
- Very crowded head term. Many established tools.
- ttviewer.net ranks strong here with only DR 9 — proves this SERP is winnable without heavy backlinks. Page quality + feature depth matter more than DR.
- Aggregators (trollishly) rank on brand strength, weak on tool UX.

### Competitor weak points (where TokGhost wins)
- ttviewer: tool-only pages, no deep informational content, no Live viewer. DR only 9 = few backlinks = beatable.
- shipname: 2 pages, DR 0, extremely thin. Easy to outrank on depth.
- snaptik/tikvib: heavy ads (they admit it), cluttered UX. TokGhost = clean, low-ad.
- Most rivals bury the tool below marketing copy. TokGhost puts tool above the fold.

### On-page meta (LOCKED)
- Slug: /  (root)
- Title (58 chars): Anonymous TikTok Viewer: View Profiles & Videos Free
- Meta description (150 chars): View TikTok profiles anonymously with TokGhost. Browse videos, followers, likes and comments and download without a watermark. No login, no trace, free.
- H1: View any TikTok profile anonymously

---

## PAGE 2 — STORY VIEWER  [HTML: building]

### Target keywords
- Primary: tiktok story viewer
- Secondary: anonymous tiktok story viewer, view tiktok stories without account, tiktok story download by username, watch tiktok stories anonymously

### Live SERP analysis (checked)
Who ranks: tikvib.com, ddtik.com, spybroski.com, snaptik.kim, exporttok.com, ttviewer.net/tiktok-story, snaptikid.com + TWO informational results (getassist forum, morelogin blog)
- KEY INSIGHT: Google ranks informational content here too, not just tools. This is the opening: competitors (ttviewer, shipname) have NO quality blog content. TokGhost can win the informational angle with its content strength.
- "tiktok story download by username" is a strong long-tail sub-phrase competitors repeat heavily — worth targeting in copy.
- Biggest single sub-keyword in the niche. High priority.

### Competitor weak points (where TokGhost wins)
- ttviewer/tiktok-story: solid tool page but no supporting blog article to reinforce it. Thin topical support.
- spybroski/snaptik: ad-heavy, and pages are marketing-copy-first, tool-second.
- No competitor pairs the tool page WITH a strong "how to view stories anonymously" article. TokGhost does both (tool page + /blog article internally linked) = topical authority they lack.
- Emphasize download-before-24h-expiry angle; users search this with urgency.

### On-page meta (LOCKED)
- Slug: /tiktok-story-viewer
- Title (57 chars): Anonymous TikTok Story Viewer: Watch & Save Free
- Meta description (149 chars): Watch TikTok stories anonymously and download them in HD before they disappear. Enter any username, no login, no trace. Free TikTok story viewer.
- H1: Anonymous TikTok Story Viewer

---

## PAGE 3 — VIDEO DOWNLOADER (NO WATERMARK)  [HTML: building]

### Target keywords
- Primary: tiktok video downloader without watermark
- Secondary: download tiktok no watermark, tiktok downloader hd, save tiktok video mp4, tiktok watermark remover

### Live SERP analysis (checked)
Who ranks: ssstik.io, snaptik.app + snaptik.sbs (multiple domains), ttdownloader.tools, armfulmedia.com, plus Google Play apps
- HARDEST keyword in the niche. Massive established players (SSSTik, SnapTik run multiple domains each). Google Play apps also compete.
- Do NOT expect to rank top 3 fast here. This is a long-game page.
- BUT: huge volume, so even page 2-3 ranking sends traffic. Worth having, not worth obsessing early.
- Angle competitors use heavily: "repost to Reels/Shorts without watermark" (creator use-case). Good copy angle.

### Competitor weak points (where TokGhost wins)
- ssstik/snaptik: extremely ad-heavy, cluttered, multiple redirect steps. TokGhost = clean, no popups.
- They are downloader-only. TokGhost bundles downloader INTO a full viewer suite (cross-linked), which builds more topical authority than a standalone downloader.
- armfulmedia ranks with an ad-free angle — proves "no ads" is a real differentiator users want. Lean into it.

### On-page meta (LOCKED)
- Slug: /tiktok-video-downloader
- Title (56 chars): TikTok Video Downloader No Watermark: Save HD Free
- Meta description (147 chars): Download TikTok videos without a watermark in HD. Paste any link and save clean MP4 files instantly. Free, no login, no app. TikTok downloader online.
- H1: TikTok Video Downloader Without Watermark

---

## PAGE 4 — LIVE VIEWER  [HTML: building]  [BIGGEST QUICK-WIN]

### Target keywords
- Primary: tiktok live viewer anonymous
- Secondary: watch tiktok live anonymously, tiktok live viewer, view tiktok live without account, watch tiktok live without being seen

### Live SERP analysis (checked)
Who ranks: itopvpn.com (blog), multilogin.com (blog), TikTok's own /discover pages, tik.ninja (general viewer)
- CRITICAL FINDING: NO dedicated tool page ranks here. Only blog posts + TikTok discover pages. The SERP is wide open for a purpose-built tool page.
- ttviewer does NOT have this page (their FAQ says Live "not supported"). Zero direct competition from the main rivals.
- This is the single best quick-win in the whole site. A proper Live viewer page can rank with little resistance.
- Reality note: true anonymous third-party Live viewing is technically limited. Page should be honest: help + attempt + explain what's possible. Still captures the search intent + traffic.

### Competitor weak points (where TokGhost wins)
- Rivals treat this as informational only (blogs). No one offers an actual tool interface for it.
- TokGhost offers a tool attempt PLUS an honest explainer = best of both, matches Google's mixed intent (tools + info both rank).
- Being first with a dedicated /tiktok-live-viewer page = topical ownership before rivals wake up.

### On-page meta (LOCKED)
- Slug: /tiktok-live-viewer
- Title (54 chars): Anonymous TikTok Live Viewer: Watch Without Being Seen
- Meta description (150 chars): Watch TikTok live streams anonymously without your name showing. Enter a username to view public lives without an account. Free anonymous TikTok live viewer.
- H1: Anonymous TikTok Live Viewer

---

## PAGES 5-12 — REMAINING TOOL PAGES (batch)

These are lower-competition long-tail pages. Same template, keyword-specific copy.
Competitor benchmark: ttviewer has repost/comment/follower/following/highlight; TokGhost matches + adds photo & mp3 as dedicated pages.

### PAGE 5 — REPOST VIEWER
- Slug: /tiktok-repost-viewer
- Primary: tiktok repost viewer | Secondary: view tiktok reposts, see someone's reposts anonymously
- SERP: ttviewer, tik.ninja rank. Low-medium competition. Winnable.
- Weak point of rivals: thin copy, no supporting content. TokGhost = fuller page + cross-links.
- Title (52): TikTok Repost Viewer: See Reposts Anonymously Free
- Desc (146): View anyone's TikTok reposts anonymously. Enter a username to see every video they reshared, with no login and no trace. Free TikTok repost viewer.
- H1: Anonymous TikTok Repost Viewer

### PAGE 6 — COMMENT VIEWER
- Slug: /tiktok-comment-viewer
- Primary: tiktok comment viewer | Secondary: view tiktok comments anonymously, read tiktok comments without account
- SERP: ttviewer, tik.ninja. Low-medium competition.
- Weak point: rivals show comments but no export/search angle. TokGhost can add "read full threads" framing.
- Title (54): TikTok Comment Viewer: Read Comments Anonymously
- Desc (143): Read all comments on any public TikTok video anonymously. Enter a link to view full comment threads with no login and no trace. Free comment viewer.
- H1: Anonymous TikTok Comment Viewer

### PAGE 7 — FOLLOWER VIEWER
- Slug: /tiktok-follower-viewer
- Primary: tiktok follower viewer | Secondary: view tiktok followers, check follower list anonymously
- SERP: ttviewer. Low competition.
- Title (52): TikTok Follower Viewer: See Followers Anonymously
- Desc (144): View any public account's TikTok followers anonymously. Enter a username to see follower counts and lists with no login. Free follower viewer.
- H1: Anonymous TikTok Follower Viewer

### PAGE 8 — FOLLOWING VIEWER
- Slug: /tiktok-following-viewer
- Primary: tiktok following viewer | Secondary: see who someone follows on tiktok
- SERP: ttviewer. Low competition.
- Title (55): TikTok Following Viewer: See Who They Follow Free
- Desc (145): See who any public account follows on TikTok anonymously. Enter a username to view their following list with no login, no trace. Free following viewer.
- H1: Anonymous TikTok Following Viewer

### PAGE 9 — PHOTO / AVATAR DOWNLOADER
- Slug: /tiktok-photo-downloader
- Primary: tiktok photo download | Secondary: tiktok profile picture viewer full size, download tiktok avatar, tiktok slideshow download
- SERP: snaptik, mixed. Medium competition but strong long-tail (profile picture full size).
- Weak point: few tools do full-size avatar well. Good sub-niche to own.
- Title (53): TikTok Photo Downloader: Save Images & Avatars HD
- Desc (147): Download TikTok photos, slideshows and profile pictures in full HD. Paste a link or username to save images with no watermark. Free photo downloader.
- H1: TikTok Photo & Avatar Downloader

### PAGE 10 — HIGHLIGHT VIEWER
- Slug: /tiktok-highlight-viewer
- Primary: tiktok highlight viewer | Secondary: view tiktok highlights, old tiktok stories
- SERP: ttviewer (they added this June 2026). Low competition, newer keyword.
- Title (53): TikTok Highlight Viewer: Watch Highlights Anonymous
- Desc (144): Watch anyone's TikTok highlights and older stories anonymously. Enter a username to view saved highlights with no login. Free highlight viewer.
- H1: Anonymous TikTok Highlight Viewer

### PAGE 11 — AUDIO / MP3 DOWNLOADER
- Slug: /tiktok-mp3-downloader
- Primary: tiktok mp3 download | Secondary: download tiktok sound, tiktok audio downloader, tiktok to mp3
- SERP: snaptik, ssstik do this. Medium competition, high volume.
- Title (52): TikTok MP3 Downloader: Save Sounds & Audio Free
- Desc (143): Extract and download audio from any TikTok video as MP3. Paste a link to save the sound in high quality with no login. Free TikTok to MP3.
- H1: TikTok MP3 & Sound Downloader

### PAGE 12 — COPY LINK UTILITY
- Slug: /copy-tiktok-link
- Primary: copy tiktok link | Secondary: get tiktok video url, clean tiktok link
- SERP: ttviewer has this. Very low competition, utility long-tail.
- Title (50): Copy TikTok Link: Get a Clean Shareable URL Free
- Desc (142): Get a clean, shareable TikTok link fast. Paste any TikTok URL to copy a tidy version with no tracking parameters. Free copy link tool.
- H1: Copy TikTok Link

---
