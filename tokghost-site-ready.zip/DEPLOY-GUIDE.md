# TokGhost — Deploy & Backend Guide

Everything needed to take the site live on Vercel and understand the free-to-paid path.

---

## What you have

- 12 tool pages + 5 legal pages, all SEO-optimized (see TokGhost-SEO-Tracker.md)
- Shared styles.css + app.js (app.js now calls the real backend)
- /api/tiktok.js — a Vercel serverless function that fetches TikTok data
- vercel.json (clean URLs), robots.txt, sitemap.xml, favicons

---

## Step 1 — Deploy the frontend + backend to Vercel

1. Put the whole folder (including the /api folder) into a GitHub repo, OR
   drag-drop the folder into vercel.com > New Project.
2. Vercel auto-detects it as a static site with serverless functions.
   No build command needed.
3. After deploy, your clean URLs work automatically:
   - tokghost.com/  (homepage)
   - tokghost.com/tiktok-story-viewer  (no .html shown)
   - tokghost.com/api/tiktok?type=profile&u=tiktok  (the backend)
4. Point your domain (tokghost.com) at the Vercel project in Settings > Domains.

---

## Step 2 — What works on the FREE tier (day one, no cost)

The backend uses TikTok's official public oEmbed. On the free tier:

- Video/comment/copy-link pages: paste a TikTok VIDEO link -> returns the
  author, title, and thumbnail (from oEmbed). Enough to be a real, working tool.
- Profile pages: confirm the username and link out to the profile.

What the free tier CANNOT do (this is the honest limit):
- Full follower/following lists, full video grids, and watermark-free MP4
  downloads. TikTok does not expose these for free; they need a data API.

This is expected and is exactly the free-vs-paid tradeoff. The site is still
fully indexable and useful, and every page ranks on its content regardless.

---

## Step 3 — Upgrade to the PAID data API (once traffic/revenue starts)

The backend already has the upgrade slot built in. To turn on full data
(followers, video lists, watermark-free downloads):

1. Sign up for a TikTok data/scraping API. Common options (compare pricing):
   - RapidAPI "TikTok" endpoints (many providers, cheap starter tiers)
   - Apify TikTok scrapers
   - ScrapTik / TikAPI style providers
2. In Vercel > Settings > Environment Variables, add:
   - TIKTOK_API_URL  = your provider's profile endpoint base URL
   - TIKTOK_API_KEY  = your provider's key
3. Redeploy. The backend automatically switches from free -> paid and starts
   returning full data. No code change needed. (See paidProfile() in api/tiktok.js;
   adapt the request shape to match your chosen provider's docs.)

Budget note: reliable APIs are usage-priced. Start on the cheapest tier, let
AdSense revenue cover it, then scale. This is the loop discussed from the start.

---

## Step 4 — Moving to WordPress later

When you migrate to WordPress:
- Each HTML tool page becomes a page template (the structure is clean and reusable).
- The /api/tiktok backend can stay on Vercel as a standalone API, and WordPress
  pages just call it via fetch() the same way app.js does now. You do NOT have to
  rebuild the backend in PHP.
- Keep the same slugs so you don't lose any SEO equity.

---

## Reality check on ranking + $10k

- Ranking takes 6-12 months in this competitive niche. The foundation here is
  strong, but Google needs time.
- $10k requires volume. In this niche AdSense RPM is modest, so the real revenue
  engine is Phase 2 (16 languages) + Phase 3 (Instagram/Snapchat expansion), not
  the 12 English pages alone.
- Next best moves after deploy: (1) blog articles to build topical authority,
  (2) submit sitemap to Google Search Console, (3) apply for AdSense once the
  legal pages + a few blog posts are live.
